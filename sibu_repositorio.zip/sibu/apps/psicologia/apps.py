from django.apps import AppConfig


class PsicologiaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.psicologia"
    verbose_name = "Psicología"
